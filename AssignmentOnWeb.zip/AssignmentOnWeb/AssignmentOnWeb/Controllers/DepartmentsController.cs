﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignmentOnWeb.BLL;
using AssignmentOnWeb.Models;

namespace AssignmentOnWeb.Controllers
{
    public class DepartmentsController : Controller
    {
        private DepartmentManager _manager = new DepartmentManager();

        [HttpGet]
        public ViewResult Add()
        {
            return View();

        }

        [HttpPost]
        public ViewResult Add(Department model)
        {
            bool isSaved = false;
            if (model.Name != null)
            {
                isSaved = _manager.Add(model);
            }

            if (isSaved)
            {
                ViewBag.SMsg = "Saved Successfully";
            }
            else
            {
                ViewBag.FMsg = "Saved Failed";
            }
            return View(model);

        }

        [HttpGet]
        public ActionResult Search()
        {
            Department department = new Department();
            List<Department> dataList = _manager.Show(department);
            return View(dataList);
        }
        

        [HttpPost]
        public ActionResult Search(Department department)
        {
            List<Department> dataList = _manager.Show(department);
            return View(dataList);
        }

        public ActionResult Edit(int id)
        {
            Department department = _manager.GetById(id);
            return View(department);
        }
        
        [HttpPost]
        public ActionResult Edit(Department department)
        {
            var isUpdate = _manager.Update(department);
            if (isUpdate)
            {

                return RedirectToAction("Search");
            }
            ViewBag.FMsg = "sorry , Update failed";
            return View(department);
        }

        public ActionResult Delete(int id)
        {
            Department department = _manager.GetById(id);
            return View(department);
        }
        [HttpPost]
        public ActionResult Delete(Department department)
        {
            bool isDelete = _manager.Delete(department);
            if (isDelete)
            {

                return RedirectToAction("Search");
            }
            ViewBag.FMsg = "sorry , Update failed";
            return View(department);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using AssignmentOnWeb.Models;

namespace AssignmentOnWeb.DatabaseContext
{
    public class DepartmentDbContext : DbContext
    {
        public DbSet<Department> Departments { get; set; }

    }
}
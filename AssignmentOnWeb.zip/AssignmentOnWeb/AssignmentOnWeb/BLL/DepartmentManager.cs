﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AssignmentOnWeb.Models;
using AssignmentOnWeb.Repositories;

namespace AssignmentOnWeb.BLL
{
    public class DepartmentManager
    {
        DepartmentRepository _repository = new DepartmentRepository();

        public bool Add(Department department)
        {
            return _repository.Add(department);
        }

        public List<Department> Show(Department department)
        {
            return _repository.Show(department);
        }
        public Department GetById(int id)
        {
            return _repository.GetById(id);

        }

        public bool Update(Department department)
        {
            return _repository.Update(department);
        }

        public bool Delete(Department department)
        {
            return _repository.Delete(department);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AssignmentOnWeb.DatabaseContext;
using AssignmentOnWeb.Models;

namespace AssignmentOnWeb.Repositories
{
    public class DepartmentRepository
    {
        DepartmentDbContext db = new DepartmentDbContext();

        public bool Add(Department department)
        {
            db.Departments.Add(department);
            int isSaved = db.SaveChanges();
            if (isSaved > 0)
            {
                return true;
            }
            return false;
        }

        public List<Department> Show(Department department)
        {
             
            if (department.Name != null)
            {
                List<Department> departments = new List<Department> { db.Departments.Where(c => c.Name == department.Name).FirstOrDefault() };
                return departments;
            }

            else
            {
                List<Department> departments = db.Departments.ToList();
                return departments;
            }
            
        }

        public bool Update(Department department)
        {

            Department oldDepartment = db.Departments.FirstOrDefault(c => c.Id == department.Id);
            if (oldDepartment != null)
            {
                oldDepartment.Name = department.Name;
                oldDepartment.Email = department.Email;
                oldDepartment.Contact = department.Contact;
            }
            int isUpdate = db.SaveChanges();
            if (isUpdate > 0)
            {
                return true;
            }

            return false;
        }

        public bool Delete(Department department)
        {
            Department oldDepartment = db.Departments.FirstOrDefault(c => c.Name == department.Name);
            if (oldDepartment != null)
            {
                db.Departments.Remove(oldDepartment);
            }
            int isUpdate = db.SaveChanges();
            if (isUpdate > 0)
            {
                return true;
            }

            return false;
            
        }

        public Department GetById(int id)
        {
            return db.Departments.FirstOrDefault(c => c.Id == id);

        }

    }
}